<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Health & Nutrition Dairy</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"
     integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" 
     crossorigin="anonymous">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Solution Of Book</title>
    <link rel="stylesheet" href="styleo.css">
    
<style>
body {
  background: url(uploa.jpg);
}
input[type=text] {
  border: 2px solid red;
  border-radius: 4px;
}


a:link {
  color: green;
  background-color: transparent;
  text-decoration: none;
}
a:visited {
  color: blue;
  background-color: transparent;
  text-decoration: none;
}
a:hover {
  color: green;
  background-color: transparent;
  text-decoration: underline;
}
a:active {
  color: yellow;
  background-color: transparent;
  text-decoration: underline;
}


</style>


</head>


<body>


    <nav>

        <label class="logo">Health and Nuitration Dairy</label>

        <ul>
            <li><a class="active"  href="homepage.php">Home</a></li> 
             <li><a class="active"   href=index.php">Live Chat</a></li>
            <li><a class="active"  href="upload.php">Emergency</a></li>
            <li><a class="active"   href="registration.php">Appointment</a></li>
            <li><a class="active"                 href="fit.html">Daily Care </a></li>
             <li><a class="active"                 href="#">Search </a></li>
        </ul>
    </nav>
    <div>
        <h1>Visit Their  Profile</h1>
        
    </div>
    <div class="container">
    <input type="text" name="search" id="search" placeholder="Enter a Name..." >
   
    
    <table>
        <thead>
    <tr>
        <td><h4>Doctor Name </h4></td>
        <td><h4>Department</h4></td>
        <td> <h4>Visit link </h4></td>
    </tr>
    </thead>
    <tbody></tbody>
    <tr>
        <td> <p style="color:red;">Dr.Husnayen</p></td>
        <td><p style="color:#B22222;">Cardiology</p> </td>
        <td> <a href="http://www.doc2p.com/doctor/70/dr-husnayen">http://www.doc2p.com/doctor/70/dr-husnayen</a> </td>
    </tr>

    <tr>
        <td> <p style="color:red;">Dr.Most. Bilkis Fatema</p></td>
        <td><p style="color:#B22222;"> Colorectal Surgery</p></td>
        <td><a href="http://www.doc2p.com/doctor/65/dr-most-bilkis-fatema">http://www.doc2p.com/doctor/65/dr-most-bilkis-fatema/</td>
    </tr>


    

    <tr>
    <td><p style="color:red;">Dr. M. R. Karim (Reza)</p></td>
    <td><p style="color:#B22222;">Spinal and Orthopedic SurgeonSpinal and Orthopedic Surgeon </p></td>
    <td><a href="http://www.doc2p.com/doctor/63/dr-m-r-karim-reza">http://www.doc2p.com/doctor/63/dr-m-r-karim-reza</td>
    </tr>

    <tr>
    <td> <p style="color:red;">Dr.Marium Begum</p></td>
    <td> <p style="color:#B22222;">Paediatrics e.g. Infant, Child, etc.</p></td>
    <td><a href="http://www.doc2p.com/doctor/61/dr-marium-begum">http://www.doc2p.com/doctor/61/dr-marium-begum</td>
    </tr>


    <tr>
    <td> <p style="color:red;">Dr.Jinnat Ara Islam</p></td>
    <td><p style="color:#B22222;">Gynaecology and Obstetrics</p></td>
    <td><a href="http://www.doc2p.com/doctor/64/dr-jinnat-ara-islam/">http://www.doc2p.com/doctor/61/dr-marium-begum</td>
    </tr>

    <tr>
    <td> <p style="color:red;">Dr.Md. Abdur Rashid</p></td>
    <td><p style="color:#B22222;">Ophthalmology</p></td>
    <td><a href="http://www.doc2p.com/doctor/62/dr-md-abdur-rashid">http://www.doc2p.com/doctor/62/dr-md-abdur-rashid</td>
    </tr>


    <tr>
    <td> <p style="color:red;">Dr.Md. Rehan Habib</p></td>
    <td><p style="color:#B22222;">Gastroenterology</p></td>
    <td><a href="http://www.doc2p.com/doctor/59/dr-md-rehan-habib ">http://www.doc2p.com/doctor/59/dr-md-rehan-habib</td>
    </tr>


    <tr>
    <td> <p style="color:red;">Dr.Chandra Shekhar Bala</p></td>
    <td><p style="color:#B22222;">  Medicine (e.g. All Diseases of Adults)  </p> </td>
    <td> <a href="http://www.doc2p.com/doctor/45/dr-chandra-shekhar-bala ">http://www.doc2p.com/doctor/45/dr-chandra-shekhar-bala/</td>
    </tr>

    <tr>
    <td> <p style="color:red;">Dr.Md. Arifur Rahman</p></td>
    <td><p style="color:#B22222;"> Paediatric Surgery (e.g. Surgery for Children)</p></td>
    <td><a href="http://www.doc2p.com/doctor/44/dr-md-arifur-rahman">http://www.doc2p.com/doctor/44/dr-md-arifur-rahman</td>
    </tr>


    <tr>
    <td><p style="color:red;">Dr. Quazi Rakibul Islam</p></td>
    <td><p style="color:#B22222;">Nephrology (e.g. Kidney, Ureter, Urinary Bladder)</p></td>
    <td><a href="http://www.doc2p.com/doctor/42/dr-quazi-rakibul-islam">http://www.doc2p.com/doctor/42/dr-quazi-rakibul-islam</td>
    </tr>

    <tr>
    <td> <p style="color:red;">Dr.Shahida Choudhury</p></td>
    <td> <p style="color:#B22222;">Psychiatry (e.g. Mental Health, Drug Abuse, Depression, etc.)</p>  </td>
    <td> <a href="http://www.doc2p.com/doctor/41/dr-shahida-choudhury">http://www.doc2p.com/doctor/41/dr-shahida-choudhury</td>
    </tr>


    <tr>
    <td> <p style="color:red;">Dr.Md. Badruzzaman</p></td>
    <td><p style="color:#B22222;">Internal Medicine(e.g. All Diseases)</p> </td>
    <td> <a href="http://www.doc2p.com/doctor/39/dr-md-badruzzaman">http://www.doc2p.com/doctor/39/dr-md-badruzzaman</td>
    </tr>

    <tr>
    <td><p style="color:red;">Dr. Md. Khorshed Alam (Khokon)</p></td>
    <td><p style="color:#B22222;">Neonatology (e.g. New Born)</p></td>
    <td><a href="http://www.doc2p.com/doctor/38/dr-md-khorshed-alam-khokon">http://www.doc2p.com/doctor/38/dr-md-khorshed-alam-khokon</td>
    </tr>

    <tr>
    <td><p style="color:red;">Major General Dr. A.K.M Safiullah </p></td>
    <td><p style="color:#B22222;">Internal Medicine(e.g. All Diseases)</p> </td>
    <td><a href="http://www.doc2p.com/doctor/37/major-general-dr-akm-safiullah-khan-retd"> http://www.doc2p.com/doctor/37/major-general-dr-akm-safiullah-khan-retd</td>
    </tr>

    <tr>
    <td><p style="color:red;">Dr M. Mahfuzur Rahman Sagar </p></td>
    <td><p style="color:#B22222;">Urology (e.g. Surgery for Kidney)</p></td>
    <td><a href="http://www.doc2p.com/doctor/46/dr-m-mahfuzur-rahman-sagar">http://www.doc2p.com/doctor/46/dr-m-mahfuzur-rahman-sagar</td>
    </tr>

    <tr>
    <td><p style="color:red;">DR Shamsad Begum</p></td>
    <td><p style="color:#B22222;">Dermatology (e.g. Skin)</p></td>
    <td> <a href="http://www.doc2p.com/doctor/47/dr-shamsad-begum">
    http://www.doc2p.com/doctor/47/dr-shamsad-begum </td>
    </tr>


    <tr>
    <td> <p style="color:red;">Dr.Yeasmin Sultana</p></td>
    <td><p style="color:#B22222;">Gynaecology and Obstetrics (e.g. Pregnancy, Menstrual, Uterus</p></td>
    <td><a href=" http://www.doc2p.com/doctor/48/dr-yeasmin-sultana">http://www.doc2p.com/doctor/48/dr-yeasmin-sultana</td>
    </tr>


    <tr>
    <td> <p style="color:red;">Dr.S. M. A. Zahid</p></td>
    <td><p style="color:#B22222;"> Medicine (e.g. All Diseases of Adults) </p> </td>
    <td><a href="http://www.doc2p.com/doctor/11/dr-s-m-a-zahid">http://www.doc2p.com/doctor/11/dr-s-m-a-zahid</td>
    </tr>


    <tr>
    <td> <p style="color:red;">Dr.Sarwar Ibne Salam</p></td>
    <td> <p style="color:#B22222;">Orthopaedics (e.g. Fractures, Bone and Joint related)</p> </td>
    <td> <a href="http://www.doc2p.com/doctor/9/dr-sarwar-ibne-salam">http://www.doc2p.com/doctor/9/dr-sarwar-ibne-salam</td>
    </tr>

    
   

    <tr>
        <td><p style="color:red;">Dr.Ahmed Salam Mir</p></td>
        <td><p style="color:#B22222;">Endocrinology (e.g. Hormones, Diabetes, Thyroid, etc.)</p> </td>
        <td><a href="http://www.doc2p.com/doctor/55/ahmed-salam-mir">http://www.doc2p.com/doctor/55/ahmed-salam-mir
        </td>
    </tr>


    <tr>
        <td><p style="color:red;">Dr.Roksana Afroj</p></td>
        <td><p style="color:#B22222;">Colorectal Surgery</p> (</td>
        <td><a href="http://www.doc2p.com/doctor/58/dr-roksana-afroj">http://www.doc2p.com/doctor/58/dr-roksana-afroj</td>
    </tr>

    </tbody>

    </table>
     </div>
<script>
    const searchInput = document.getElementById("search");
    const rows = document.querySelectorAll("tbody tr");
    //console.log(rows);

    searchInput.addEventListener("keyup", function (event) {
      //console.log(event);  
    const q = event.target.value.toLowerCase();
    rows.forEach((row) => {
        row.querySelector("td").textContent.toLowerCase().startsWith(q)
         ? (row.style.display="table-row") 
        : (row.style.display = "none");
    });
});

</script>

<div class="footer">
    <div class="inner-footer">

        <div class="footer-items">
            <h1>New Invented</h1>
            <p>Content itself is what the user derives value from....</p>

        </div>

        <div class="footer-items">
            <h1>Quick Links</h1>
            <div class="border"></div>
                <ul>
                    <a href=""><li>Home</li></a>
                    <a href=""><li>Upload</li></a>
                    <a href=""><li>Search</li></a>
                    <a href=""><li>Registration</li></a>
                </ul>

        </div>
        <div class="footer-items">
            <h1>Tutorials</h1>
            <div class="border"></div>
                <ul>
                    <a href=""><li>Madical Information</li></a>
                    <a href=""><li>Embulance</li></a>
                    <a href=""><li>Technology</li></a>
                    <a href=""><li>Madicen Delivery</li></a>
                </ul>

        </div>

        <div class="footer-items">
            <h1>Contact Us</h1>
            <div class="border"></div>
                <ul>
                    <li><i class="fa fa-map-marker" aria-hidden="true"></i>15/2, Dhanmondi, Dhaka-1207</li>
                    <li><i class="fa fa-phone" aria-hidden="true"></i>+8801627162691</li>
                    <li><i class="fa fa-envelope" aria-hidden="true"></i>support@dairy.com</li>
                </ul>
                <div class="social-media">
                    <a href=""><i class="fa fa-facebook" aria-hidden="true"></i></a>
                    <a href=""><i class="fa fa-twitter" aria-hidden="true"></i></a>
                    <a href=""><i class="fa fa-instagram" aria-hidden="true"></i></a>
                    <a href=""><i class="fa fa-facebook" aria-hidden="true"></i></a>
                    <a href=""><i class="fa fa-google-plus" aria-hidden="true"></i></a>
                </div>

        </div>
    </div>
    <div class="w3-container w3-teal" style="border: 1px solid black;background-color: #9932CC ">
  <footer style="width:100%; text-align: center;">
    <p>&copy; 2021 Health And Nurtation Dairy</p>
    <a href=" "> 24 hours service</a>
  </footer>


    </div>

</div>
    
</body>
</html>


</body>
</html>
